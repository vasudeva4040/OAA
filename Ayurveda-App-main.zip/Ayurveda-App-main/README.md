# Ayurveda-App


In home page NavBar you can go to admin login as there is only one admin 
If you are new customer you can register in our website u have to fill according to few rules ( validations )
If you are done registering you will be directed to login page. you can login directly by  